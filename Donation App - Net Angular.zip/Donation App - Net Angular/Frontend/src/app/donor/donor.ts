export class Donor {}
