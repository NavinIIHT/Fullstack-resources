import { Ngo } from './ngo';

describe('Ngo', () => {
  it('should create an instance', () => {
    expect(new Ngo()).toBeTruthy();
  });
});
