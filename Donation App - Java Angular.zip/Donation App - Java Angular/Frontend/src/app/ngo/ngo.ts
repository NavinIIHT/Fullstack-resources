export class Ngo {}
