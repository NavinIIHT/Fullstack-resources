import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngo',
  templateUrl: './ngo.component.html',
  styleUrls: ['./ngo.component.css'],
})
export class NgoComponent implements OnInit {
  ngOnInit(): void {
    // write your logic here
  }

  //calls when you click on Add  button
  addNgo() {
    // write your logic here
  }

  //Save Data
  postNgoData() {
    // write your logic here
  }

  //Get data
  getAllNgoData() {
    // write your logic here
  }

  //Delete data
  deleteNgo() {
    // write your logic here
  }

  // set values of specfid one to html form fields to edit
  ngoEdit() {
    // write your logic herAaz
  }

  //Update  data
  updateNgoData() {}
}
