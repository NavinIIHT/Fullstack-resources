export class Donation {}
